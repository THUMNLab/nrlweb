Reference:

Traud, A. L.; Mucha, P. J.; and Porter, M. A. 2012. Social structure of facebook networks. Physica A: Statistical Mechanics and its Applications 391(16):4165�C4180.